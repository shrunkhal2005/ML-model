from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import pandas as pd
import datetime

# Google Fit API scopes
SCOPES = [
    'https://www.googleapis.com/auth/fitness.activity.read',
    'https://www.googleapis.com/auth/fitness.heart_rate.read',
    'https://www.googleapis.com/auth/fitness.body.read'
]

# Load credentials and authenticate
flow = InstalledAppFlow.from_client_secrets_file(
    'client_secret_520826333311-dl6eoi8hinnbe5aq7d9n0uqq41rue7ji.apps.googleusercontent.com.json',
    SCOPES
)
creds = flow.run_local_server(port=0)

# Build the Fitness API service
service = build('fitness', 'v1', credentials=creds)

# Time range: last 24 hours
now = datetime.datetime.now(datetime.UTC)
yesterday = now - datetime.timedelta(days=1)

# ✅ Aggregate steps from all sources (not just phone)
steps_data = service.users().dataset().aggregate(
    userId="me",
    body={
        "aggregateBy": [{
            "dataTypeName": "com.google.step_count.delta"
        }],
        "bucketByTime": {"durationMillis": 86400000},
        "startTimeMillis": int(yesterday.timestamp() * 1000),
        "endTimeMillis": int(now.timestamp() * 1000)
    }
).execute()

# ✅ Sum total steps across all sources
total_steps = 0
for bucket in steps_data.get('bucket', []):
    for dataset in bucket['dataset']:
        for point in dataset.get('point', []):
            total_steps += point['value'][0].get('intVal', 0)

print(f"Total steps in last 24 hours: {total_steps}")
